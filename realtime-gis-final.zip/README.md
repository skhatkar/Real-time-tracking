# Real-Time GIS-Based Tracking & Mapping System (Azure-Ready)

A complete, production-style reference implementation for a GIS-enabled Real-Time Delivery Partner Tracking System.

## Highlights
- **FastAPI** backend with JWT auth, RBAC, REST + WebSocket for live updates.
- **PostgreSQL + PostGIS** schema for Agents, Locations, Routes, Geofences (SQL migrations included).
- **React + Leaflet** frontend with live markers, route panel, and geofence drawing (optional toggle).
- **Simulator** to generate GPS pings for demo.
- **Docker Compose** for easy local spin-up.
- **Azure DevOps** CI/CD pipeline yaml + Dockerfiles.
- **Azure-ready**: App Service/AKS, Key Vault usage via env vars, Azure Monitor logs (app logs to stdout).

> Built to match the "GIS Engineer- Assessment (external)" requirements (System Architecture, Frontend UI, Backend APIs, DB Design, Azure Integration, CI/CD, Security, and Docs).

---

## Quick Start (Local)

**Prereqs**: Docker + Docker Compose

```bash
# 1) Create a .env file at project root (or copy .env.example)
cp .env.example .env

# 2) Start everything
docker compose up --build

# 3) Visit the frontend
# Default: http://localhost:5173

# Backend docs (Swagger/OpenAPI)
# http://localhost:8000/docs
```

> The DB will auto-init with PostGIS and migrate tables. The frontend will poll and subscribe for live updates.

### Demo data (simulator)
Open a new terminal:
```bash
# Send simulated GPS pings for two agents
docker compose exec backend bash -lc "python -m app.simulator.send_updates --agents 2 --city shimla"
```

---

## Project Structure
```
/backend       FastAPI service, JWT, RBAC, REST + WS, SQLAlchemy, tests
/frontend      React+Vite+Leaflet UI, auth, map, route/geofence tools
/infra         Docker, Azure DevOps pipeline, k8s manifests (optional)
/docs          Architecture (Mermaid), API Usage, Data model
/db            PostGIS migrations (SQL)
docker-compose.yml
.env.example
```

---

## Environment Variables

See `.env.example` for all options. Key ones:
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`
- `DATABASE_URL` (backend): e.g. `postgresql+psycopg2://user:pass@db:5432/gisdb`
- `JWT_SECRET`, `JWT_ALGO`
- `CORS_ORIGINS` (comma-separated)
- `OPENROUTESERVICE_API_KEY` (optional; if set, backend will request optimized routes)

In Azure, store secrets in **Key Vault** & inject to the app via App Settings.

---

## Azure Notes (High Level)
- Deploy **backend** container to App Service or AKS.
- Deploy **frontend** to Static Web Apps or App Service (container).
- Put **Azure Application Gateway** in front for TLS + WAF.
- Store secrets in **Azure Key Vault**; managed identity grants access.
- Send logs/metrics to **Azure Monitor** (container logs).
- Optional: push raw GPS pings to Data Lake via a separate event pipeline.

See `/infra/azure-pipelines.yml` and comments in manifests.

---

## Testing & Quality
- Unit tests: `pytest`
- Linting: `flake8` for Python, `eslint` for frontend
- Types: Pydantic models for request/response validation

---

## License
MIT


## Switching to React Frontend (Optional)

If you want to run the React frontend (optional), go to `/frontend` (or `/frontend-react`) and run it manually:

```bash
cd frontend
npm install
npm run dev
```

Or add the React service to `docker-compose.yml` and rebuild. The default compose runs the Python Folium UI at `/map`.
