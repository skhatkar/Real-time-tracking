from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .config import CORS_ORIGINS
from . import routes_auth, routes_location, routes_route, routes_geofence
import folium
import os

app = FastAPI(title="Real-Time GIS Tracking API (Python-Folium)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS if CORS_ORIGINS else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_auth.router)
app.include_router(routes_location.router)
app.include_router(routes_route.router)
app.include_router(routes_geofence.router)

templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "..", "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "..", "static")), name="static")

@app.get("/health")
def health():
    return {"status":"ok"}

@app.get("/map")
def map_view(request: Request):
    # create a Folium map centered on Shimla
    m = folium.Map(location=[31.1048, 77.1734], zoom_start=12)
    # expose map's HTML and script
    map_html = m._repr_html_()
    # build ws url (ws:// or wss:// depending on scheme)
    scheme = "ws"
    host = os.getenv("HOST_OVERRIDE", "localhost:8000")
    ws_url = f"{scheme}://{host}/location/ws"
    return templates.TemplateResponse("map.html", {"request": request, "folium_map": map_html, "ws_url": ws_url})
