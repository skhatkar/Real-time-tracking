from sqlalchemy import Column, Integer, String, Text, DateTime, Float, ForeignKey, func
from sqlalchemy.orm import relationship
from geoalchemy2 import Geometry
from .database import Base

class Agent(Base):
    __tablename__ = "agents"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(Text, nullable=False)
    email = Column(Text, nullable=False, unique=True, index=True)
    role = Column(Text, default="Agent", nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    locations = relationship("Location", back_populates="agent")

class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id", ondelete="CASCADE"), nullable=False, index=True)
    ts = Column(DateTime, server_default=func.now(), index=True)
    lat = Column(Float, nullable=False)
    lng = Column(Float, nullable=False)
    geom = Column(Geometry(geometry_type='POINT', srid=4326))

    agent = relationship("Agent", back_populates="locations")

class Route(Base):
    __tablename__ = "routes"
    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id", ondelete="SET NULL"))
    name = Column(Text)
    created_at = Column(DateTime, server_default=func.now())
    geom = Column(Geometry(geometry_type='LINESTRING', srid=4326))

class Geofence(Base):
    __tablename__ = "geofences"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(Text, nullable=False)
    description = Column(Text)
    geom = Column(Geometry(geometry_type='POLYGON', srid=4326), nullable=False)
    created_by = Column(Integer, ForeignKey("agents.id", ondelete="SET NULL"))
    created_at = Column(DateTime, server_default=func.now())
