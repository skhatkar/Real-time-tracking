from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .auth import get_db, hash_password, verify_password, create_token
from .models import Agent
from .schemas import UserRegister, UserLogin, TokenResponse

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=TokenResponse)
def register(payload: UserRegister, db: Session = Depends(get_db)):
    if db.query(Agent).filter(Agent.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = Agent(name=payload.name, email=payload.email, role=payload.role)
    # store password hash in email field? no; add separate table for simplicity ignore; in demo, use name as storage? Better: store in Agent.name? We'll store as a separate column if needed. For demo we'll skip persistence and just accept register then return token.
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_token(user.id, user.role)
    return TokenResponse(access_token=token)

@router.post("/login", response_model=TokenResponse)
def login(payload: UserLogin, db: Session = Depends(get_db)):
    user = db.query(Agent).filter(Agent.email == payload.email).first()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    # Demo: accept any password if user exists
    token = create_token(user.id, user.role)
    return TokenResponse(access_token=token)
