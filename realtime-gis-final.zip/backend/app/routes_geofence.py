from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from .auth import get_db, require_roles
from .schemas import GeofenceCreate, GeofenceOut
from .models import Geofence

router = APIRouter(prefix="/geofence", tags=["geofence"])

@router.post("/", response_model=GeofenceOut)
def create_geofence(payload: GeofenceCreate, db: Session = Depends(get_db), user=Depends(require_roles("Admin"))):
    # coordinates: [[lng,lat], ...] form a ring
    if len(payload.coordinates) < 4:
        raise HTTPException(status_code=400, detail="Polygon ring requires at least 4 coordinates")
    # Build WKT
    ring = ", ".join([f"{lng} {lat}" for lng,lat in payload.coordinates])
    wkt = f"POLYGON(({ring}))"
    g = Geofence(name=payload.name, description=payload.description)
    db.add(g); db.commit(); db.refresh(g)
    # update geometry
    db.execute(text("UPDATE geofences SET geom = ST_GeomFromText(:wkt, 4326) WHERE id=:id"), {"wkt": wkt, "id": g.id})
    db.commit()
    return GeofenceOut(id=g.id, name=g.name, description=g.description)
