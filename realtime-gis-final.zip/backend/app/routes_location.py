from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Dict, List
from .auth import get_db, get_current_user, require_roles
from .models import Location, Agent, Geofence
from .schemas import LocationUpdate, LocationOut
from shapely.geometry import Point, Polygon

router = APIRouter(prefix="/location", tags=["location"])

# In-memory subscriber list for WS broadcasts
active_sockets: List[WebSocket] = []

async def broadcast(message: dict):
    dead = []
    for ws in active_sockets:
        try:
            await ws.send_json(message)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_sockets.remove(ws)
        except ValueError:
            pass

@router.post("/update")
async def update_location(payload: LocationUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    agent = db.query(Agent).filter(Agent.id == payload.agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    loc = Location(agent_id=payload.agent_id, lat=payload.lat, lng=payload.lng)
    db.add(loc)
    db.commit()
    db.refresh(loc)

    # Geofence check
    alerts = []
    fences = db.query(Geofence).all()
    p = Point(payload.lng, payload.lat)
    for f in fences:
        # fetch WKT polygon
        poly_wkt = db.execute(text("SELECT ST_AsText(geom) FROM geofences WHERE id=:id"), {"id": f.id}).scalar()
        if poly_wkt:
            from shapely import wkt as swkt
            poly = swkt.loads(poly_wkt)
            if poly.contains(p):
                alerts.append({"geofence_id": f.id, "name": f.name, "event": "inside"})

    msg = {"type":"location_update","data":{"agent_id":agent.id,"lat":payload.lat,"lng":payload.lng,"ts":str(loc.ts),"alerts":alerts}}
    await broadcast(msg)

    return {"ok": True, "id": loc.id, "alerts": alerts}

@router.get("/latest/{agent_id}", response_model=LocationOut)
def latest(agent_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    loc = db.query(Location).filter(Location.agent_id == agent_id).order_by(Location.ts.desc()).first()
    if not loc:
        raise HTTPException(status_code=404, detail="No location")
    return loc

@router.get("/history/{agent_id}", response_model=List[LocationOut])
def history(agent_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(Location).filter(Location.agent_id == agent_id).order_by(Location.ts.asc()).all()
    return items

@router.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_sockets.append(websocket)
    try:
        while True:
            # Clients may ping
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in active_sockets:
            active_sockets.remove(websocket)
