from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import requests, os
from math import radians, sin, cos, sqrt, atan2
from .auth import get_current_user
from .schemas import RouteOptimizeRequest, RouteOptimizeResponse
from .config import OPENROUTESERVICE_API_KEY

router = APIRouter(prefix="/route", tags=["route"])

def haversine_km(a, b):
    R = 6371.0
    lat1, lon1 = a
    lat2, lon2 = b
    dlat = radians(lat2-lat1); dlon = radians(lon2-lon1)
    s = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
    c = 2 * atan2(sqrt(s), sqrt(1-s))
    return R*c

@router.post("/optimize", response_model=RouteOptimizeResponse)
def optimize(payload: RouteOptimizeRequest, user=Depends(get_current_user)):
    if not payload.stops or len(payload.stops) < 2:
        raise HTTPException(status_code=400, detail="Need at least 2 stops")
    if OPENROUTESERVICE_API_KEY:
        try:
            url = "https://api.openrouteservice.org/v2/directions/driving-car/geojson"
            coords = [[lng, lat] for lat, lng in payload.stops]
            body = { "coordinates": coords, "optimize_waypoints": True }
            headers = { "Authorization": OPENROUTESERVICE_API_KEY, "Content-Type": "application/json" }
            r = requests.post(url, json=body, headers=headers, timeout=10)
            r.raise_for_status()
            data = r.json()
            ordered = [(c[1],c[0]) for c in data["features"][0]["geometry"]["coordinates"]]
            dist = data["features"][0]["properties"]["segments"][0]["distance"]/1000
            return RouteOptimizeResponse(ordered_stops=ordered, distance_km=dist)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"ORS error: {e}")
    # fallback: nearest-neighbor heuristic
    ordered = [payload.stops[0]]
    remaining = payload.stops[1:].copy()
    while remaining:
        last = ordered[-1]
        nxt = min(remaining, key=lambda s: haversine_km(last, s))
        ordered.append(nxt)
        remaining.remove(nxt)
    dist = sum(haversine_km(ordered[i], ordered[i+1]) for i in range(len(ordered)-1))
    return RouteOptimizeResponse(ordered_stops=ordered, distance_km=dist)
