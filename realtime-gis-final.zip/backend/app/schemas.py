from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime

# Auth
class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str = "Agent"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

# Location
class LocationUpdate(BaseModel):
    agent_id: int
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    ts: Optional[datetime] = None

class LocationOut(BaseModel):
    id: int
    agent_id: int
    ts: datetime
    lat: float
    lng: float

    class Config:
        from_attributes = True

# Route optimize
class RouteOptimizeRequest(BaseModel):
    stops: list[tuple[float, float]]  # [(lat, lng), ...]

class RouteOptimizeResponse(BaseModel):
    ordered_stops: list[tuple[float, float]]
    distance_km: float

# Geofence
class GeofenceCreate(BaseModel):
    name: str
    description: str | None = None
    # geojson polygon: [[lng,lat], ...] ring
    coordinates: list[list[float]]

class GeofenceOut(BaseModel):
    id: int
    name: str
    description: str | None
