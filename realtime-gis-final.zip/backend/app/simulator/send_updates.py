import time, random, argparse, requests, os, math

API = os.getenv("API_BASE", "http://localhost:8000")
TOKEN = os.getenv("TOKEN", "")

CITIES = {
    "shimla": (31.1048, 77.1734),
    "delhi": (28.6139, 77.2090),
    "karsog": (31.3815, 77.2045),
}

def jitter(coord, dlat=0.001, dlng=0.001):
    return (coord[0] + random.uniform(-dlat, dlat), coord[1] + random.uniform(-dlng, dlng))

def main(n_agents=2, city="shimla"):
    base = CITIES.get(city.lower(), CITIES["shimla"])
    # Register agents
    tokens = []
    for i in range(n_agents):
        email = f"agent{i+1}@example.com"
        try:
            r = requests.post(f"{API}/auth/register", json={"name": f"Agent {i+1}", "email": email, "password": "x", "role":"Agent"})
            token = r.json()["access_token"]
        except Exception:
            r = requests.post(f"{API}/auth/login", json={"email": email, "password":"x"})
            token = r.json()["access_token"]
        tokens.append(token)

    # Create geofence (Admin)
    # (Optional: skip in demo)

    # Stream updates
    while True:
        for i, tok in enumerate(tokens):
            lat, lng = jitter(base, 0.003, 0.003)
            headers = {"Authorization": f"Bearer {tok}"}
            requests.post(f"{API}/location/update", json={"agent_id": i+1, "lat": lat, "lng": lng}, headers=headers, timeout=5)
        time.sleep(2)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--agents", type=int, default=2)
    ap.add_argument("--city", type=str, default="shimla")
    args = ap.parse_args()
    main(args.agents, args.city)
