-- Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Agents table
CREATE TABLE IF NOT EXISTS agents (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL DEFAULT 'Agent', -- Admin | Agent | Viewer
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Locations table (timestamped), geometry column
CREATE TABLE IF NOT EXISTS locations (
    id BIGSERIAL PRIMARY KEY,
    agent_id INTEGER NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    ts TIMESTAMP NOT NULL DEFAULT NOW(),
    lat DOUBLE PRECISION NOT NULL,
    lng DOUBLE PRECISION NOT NULL,
    geom geometry(Point, 4326) GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lng, lat), 4326)) STORED
);
CREATE INDEX IF NOT EXISTS idx_locations_agent_ts ON locations(agent_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_locations_geom ON locations USING GIST(geom);

-- Routes table
CREATE TABLE IF NOT EXISTS routes (
    id SERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(id) ON DELETE SET NULL,
    name TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    geom geometry(LineString, 4326)
);

-- Geofences table
CREATE TABLE IF NOT EXISTS geofences (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    geom geometry(Polygon, 4326) NOT NULL,
    created_by INTEGER REFERENCES agents(id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_geofences_geom ON geofences USING GIST(geom);
