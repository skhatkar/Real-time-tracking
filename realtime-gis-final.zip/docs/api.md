# API Overview

Base: `http://localhost:8000` (Dev)

- `POST /auth/register` → returns `{ access_token }`
- `POST /auth/login` → returns `{ access_token }`
- `POST /location/update` (auth) `{ agent_id, lat, lng }`
- `GET /location/latest/{agentId}` (auth)
- `GET /location/history/{agentId}` (auth)
- `POST /route/optimize` (auth) `{ stops: [[lat,lng], ...] }`
- `WS /location/ws` → real-time updates broadcast

See Swagger UI at `/docs`.
