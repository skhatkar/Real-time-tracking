# Architecture

```mermaid
flowchart LR
  subgraph Client
    UI[React + Leaflet]
  end

  subgraph Azure
    AGW[App Gateway + WAF]
    BE[App Service / AKS: FastAPI]
    DB[(PostgreSQL + PostGIS)]
    KV[Key Vault]
    MON[Azure Monitor]
  end

  UI-->AGW-->BE
  BE-->DB
  BE-->MON
  BE<-->KV
```

## Real-Time Updates
- REST `/location/update` stores point and broadcasts via WebSocket `/location/ws` to connected clients.
- Optional: MQ for scale (e.g., Redis pub/sub).

## Security
- JWT Auth, RBAC (Admin/Agent/Viewer).
- CORS & rate limiting (add gateway config).

## Data
- `agents`, `locations` (Point 4326), `routes` (LineString 4326), `geofences` (Polygon 4326).
