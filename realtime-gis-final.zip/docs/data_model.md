# Data Model (PostGIS)

- **agents**
  - id (PK), name, email (unique), role, created_at

- **locations**
  - id (PK), agent_id (FK), ts, lat, lng, geom (Point, 4326)
  - Index: (agent_id, ts desc), GIST(geom)

- **routes**
  - id (PK), agent_id (FK nullable), name, created_at, geom (LineString, 4326)

- **geofences**
  - id (PK), name, description, geom (Polygon, 4326), created_by, created_at
  - Index: GIST(geom)
