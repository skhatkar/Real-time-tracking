import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import MapView from './components/MapView.jsx'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

export default function App(){
  const [token, setToken] = useState(null)
  const [email, setEmail] = useState('admin@example.com')
  const [password, setPassword] = useState('x')
  const [agentId, setAgentId] = useState(1)
  const [last, setLast] = useState(null)

  const authHeaders = token ? { Authorization: `Bearer ${token}` } : {}

  async function ensureUser(){
    try {
      const res = await axios.post(`${API}/auth/register`, { name:"Admin", email, password, role:"Admin"})
      setToken(res.data.access_token)
    } catch {
      const res = await axios.post(`${API}/auth/login`, { email, password })
      setToken(res.data.access_token)
    }
  }

  useEffect(()=>{ ensureUser() },[])

  async function fetchLatest(){
    if(!token) return
    try{
      const res = await axios.get(`${API}/location/latest/${agentId}`, { headers: authHeaders })
      setLast(res.data)
    }catch(e){ /* ignore */ }
  }

  return (
    <div style={{height:'100%'}}>
      <header>
        <strong>Real-Time GIS Tracker</strong>
        <div className="toolbar">
          <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
          <button onClick={ensureUser}>Login</button>
          <input type="number" min={1} value={agentId} onChange={e=>setAgentId(+e.target.value)} />
          <button onClick={fetchLatest}>Latest</button>
        </div>
      </header>
      <div className="map">
        <MapView api={API} token={token} last={last} />
      </div>
    </div>
  )
}
