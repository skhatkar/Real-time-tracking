import React, { useEffect, useRef, useState } from 'react'
import L from 'leaflet'
import 'leaflet-draw/dist/leaflet.draw.css'
import 'leaflet-draw'

const defaultCenter = [31.1048, 77.1734]

export default function MapView({ api, token, last }){
  const mapRef = useRef(null)
  const markersRef = useRef({})
  const [ws, setWs] = useState(null)

  useEffect(()=>{
    if(mapRef.current) return
    const map = L.map('map').setView(defaultCenter, 13)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map)
    // Add draw control
    const drawnItems = new L.FeatureGroup()
    map.addLayer(drawnItems)
    const drawControl = new L.Control.Draw({
      edit: { featureGroup: drawnItems },
      draw: { polyline:false, circle:false, rectangle:false, marker:false, circlemarker:false }
    })
    map.addControl(drawControl)
    map.on(L.Draw.Event.CREATED, function (e) {
      const layer = e.layer
      drawnItems.addLayer(layer)
      if(layer instanceof L.Polygon){
        const coords = layer.getLatLngs()[0].map(ll=>[ll.lng,ll.lat])
        fetch(`${api}/geofence/`,{
          method:'POST',
          headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},
          body:JSON.stringify({name:'Fence', description:'Drawn polygon', coordinates:coords})
        }).then(r=>r.json()).then(console.log)
      }
    })
    mapRef.current = map
  }, [])

  useEffect(()=>{
    if(!token || ws) return
    const socket = new WebSocket(`${api.replace('http','ws')}/location/ws`)
    socket.onmessage = (ev)=>{
      const msg = JSON.parse(ev.data)
      if(msg.type === 'location_update'){
        const { agent_id, lat, lng } = msg.data
        const id = String(agent_id)
        const map = mapRef.current
        if(!map) return
        if(!markersRef.current[id]){
          markersRef.current[id] = L.marker([lat,lng]).addTo(map).bindPopup(`Agent ${id}`)
        }else{
          markersRef.current[id].setLatLng([lat,lng])
        }
      }
    }
    setWs(socket)
    return ()=> socket.close()
  }, [token])

  useEffect(()=>{
    const map = mapRef.current
    if(!map || !last) return
    map.setView([last.lat, last.lng], 14)
  }, [last])

  return <div id="map" style={{height:'100%', width:'100%'}} />
}
